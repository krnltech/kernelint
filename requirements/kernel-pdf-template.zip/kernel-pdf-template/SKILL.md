---
name: kernel-pdf-template
description: Generate professional Kernel International Ltd. branded PDF deliverables using the approved vector HTML letterhead. Use whenever creating, converting, regenerating, redesigning, or reviewing a Kernel-branded PDF, report, proposal, database design, audit, runbook, or client deliverable using the Progress Kohinoor / 01348 061944 branding.
---

# Kernel PDF Template

Generate Kernel-branded PDFs from HTML using the approved enterprise letterhead. The renderer draws the logo, header rail, footer contact strip, corner borders, icons, and footer rail as vector SVG/text so they remain sharp at every zoom level.

Treat `assets/kernel-letterhead-preview.html` as the visual source of truth. Do not improvise or redesign the repeated header/footer unless the user explicitly asks to revise the template and approves an HTML preview first.

## Required Companion Skill

Load and follow `/Users/aqib/.codex/skills/pdf/SKILL.md` for PDF extraction, rendering, visual inspection, and final quality checks. This skill's HTML/Chromium renderer takes precedence over ReportLab for Kernel-branded generation.

## Workflow

1. Gather the exact source content from the provided PDF, markdown, HTML, document, or repository files.
2. If changing the letterhead design, update and obtain approval for an HTML preview before modifying the renderer.
3. Build semantic HTML for the document body. Preserve existing content and order unless the user requests editorial changes.
4. Render with `scripts/render-kernel-pdf.mjs`.
5. Follow the PDF skill: inspect extracted text and rendered PNG pages after every meaningful update.
6. Deliver only after the latest inspection shows no clipping, overlap, broken tables, or header/footer defects.

## Approved Letterhead

- A4 portrait.
- Kernel wordmark and bulb/lightning logo from `assets/kernel-logo.svg`.
- Compact `31mm` header with an `18mm` left-aligned logo.
- Thin divider and right-aligned blue header rail with a white separator and light-blue facet.
- Compact `19mm` footer with Office and Telephone labels.
- Footer blue rail at the bottom-left with a white separator and light-blue facet.
- Subtle top-left and bottom-right L-shaped page borders inset `0.8mm` so every stroke remains visible in the exported PDF.
- Header artwork must reach the physical top page edge and the footer rail must reach the physical bottom page edge. Do not leave white bands outside the letterhead.
- Brand blue: `#1459b8`.
- Office: `Progress Kohinoor, House 18, Road 10, Gulshan 1`.
- Telephone: `01348 061944`.

Never use the legacy PNG header/footer assets. Do not rasterize the letterhead.

## Content Rules

- Keep body text selectable and use real HTML tables/diagrams where practical.
- Do not add the old metadata strip containing `Document Title`, `Date`, `Reference`, or `Version`.
- Use restrained corporate styling: white background, dark ink, Kernel blue headings, pale-blue supporting accents.
- Use A4 portrait unless the user explicitly requests another format.
- Preserve source content exactly when the user asks only for template conversion.
- Rasterize only visuals that cannot reasonably be reconstructed.

## Renderer

```bash
node /Users/aqib/.codex/skills/kernel-pdf-template/scripts/render-kernel-pdf.mjs \
  --input content.html \
  --out output.pdf \
  --title "Document title"
```

Defaults:

- Top margin: `36mm`
- Bottom margin: `20mm`
- Left/right margins: `18mm`

Useful options:

```bash
--top-margin 36mm
--bottom-margin 20mm
--left-margin 18mm
--right-margin 18mm
--wait-for-render-complete
```

Use `--wait-for-render-complete` when dynamic content sets `window.__renderComplete = true`.

The renderer intentionally translates the header upward `5mm` and the footer downward `5mm` to compensate for Chromium's internal header/footer inset. Keep this compensation together with the `36mm` top and `20mm` bottom defaults. Removing either part reintroduces unwanted white space at the page edges.

## HTML Body Pattern

```html
<section class="page">
  <p class="eyebrow">Document Category</p>
  <h1>Professional Document Title</h1>
  <p class="lead">Concise introduction or executive summary.</p>

  <h2>1. Section</h2>
  <p>Document content goes here.</p>
</section>
```

The renderer provides styles for `.page`, `.cover`, `.cover-meta`, `.toc`, `.callout`, `.erd`, tables, and headings.

## Verification

Run the PDF skill checks plus:

```bash
pdfinfo output.pdf
pdftotext -f 1 -l 3 output.pdf -
pdfimages -list output.pdf
pdftoppm -png -r 120 output.pdf /tmp/kernel-check
```

Confirm:

- Header/footer match `assets/kernel-letterhead-preview.html`.
- Header touches the top page edge and footer rail touches the bottom page edge with no external white bands.
- Logo, rails, icons, borders, and text remain sharp at high zoom.
- `pdfimages -list` shows no rasterized letterhead images.
- Content clears the `31mm` header and `19mm` footer.
- Header/footer appear consistently on every page.
- Contact details are correct.
- Latest rendered PNG inspection shows zero visual defects.
