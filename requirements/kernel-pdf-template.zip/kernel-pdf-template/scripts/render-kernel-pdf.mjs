#!/usr/bin/env node
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const skillDir = resolve(__dirname, "..");
const assetsDir = resolve(skillDir, "assets");
const requireFromCwd = createRequire(resolve(process.cwd(), "package.json"));
const { chromium } = requireFromCwd("playwright");

function usage() {
  console.error(`Usage:
  node render-kernel-pdf.mjs --input content.html --out output.pdf [options]

Options:
  --title "Title"                 PDF/document title
  --top-margin 36mm               Content top margin below Kernel header
  --bottom-margin 20mm            Content bottom margin above Kernel footer
  --left-margin 18mm              Left page margin
  --right-margin 18mm             Right page margin
  --wait-for-render-complete      Wait for window.__renderComplete === true
`);
}

function parseArgs(argv) {
  const args = {
    title: "Kernel PDF Deliverable",
    topMargin: "36mm",
    bottomMargin: "20mm",
    leftMargin: "18mm",
    rightMargin: "18mm",
    waitForRenderComplete: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = () => {
      i += 1;
      if (i >= argv.length) throw new Error(`Missing value for ${arg}`);
      return argv[i];
    };

    switch (arg) {
      case "--input":
        args.input = next();
        break;
      case "--out":
        args.out = next();
        break;
      case "--title":
        args.title = next();
        break;
      case "--top-margin":
        args.topMargin = next();
        break;
      case "--bottom-margin":
        args.bottomMargin = next();
        break;
      case "--left-margin":
        args.leftMargin = next();
        break;
      case "--right-margin":
        args.rightMargin = next();
        break;
      case "--wait-for-render-complete":
        args.waitForRenderComplete = true;
        break;
      case "--help":
      case "-h":
        usage();
        process.exit(0);
      default:
        throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!args.input || !args.out) {
    usage();
    throw new Error("--input and --out are required");
  }

  return args;
}

function hasFullHtml(source) {
  return /<!doctype html|<html[\s>]/i.test(source);
}

function fileToDataUrl(path, mimeType) {
  const bytes = readFileSync(path);
  return `data:${mimeType};base64,${bytes.toString("base64")}`;
}

function extractBody(source) {
  const match = source.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  return match ? match[1] : source;
}

function buildHtml({ title, body, extraHead = "" }) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>${escapeHtml(title)}</title>
${extraHead}
<style>
  :root {
    --ink: #151b24;
    --muted: #667085;
    --border: #dbe5f3;
    --border-strong: #b9cbe7;
    --accent: #1459b8;
    --accent-light: #eef5ff;
    --code-bg: #f7faff;
  }

  * { box-sizing: border-box; }

  html, body {
    margin: 0;
    padding: 0;
    color: var(--ink);
    font-family: Arial, Helvetica, sans-serif;
    font-size: 9.8pt;
    line-height: 1.45;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  .page { background: white; }
  .page + .page { page-break-before: always; }

  .cover {
    display: flex;
    min-height: 198mm;
    flex-direction: column;
    justify-content: space-between;
  }

  .cover-eyebrow {
    color: var(--accent);
    font-size: 8.6pt;
    font-weight: 800;
    letter-spacing: 0.18em;
    text-transform: uppercase;
  }

  .cover-title {
    margin: 10mm 0 6mm;
    color: var(--ink);
    font-size: 31pt;
    font-weight: 800;
    line-height: 1.06;
    letter-spacing: -0.04em;
  }

  .cover-subtitle {
    max-width: 138mm;
    color: var(--muted);
    font-size: 14pt;
    line-height: 1.45;
  }

  .cover-meta {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
  }

  .cover-meta > div {
    min-height: 19mm;
    padding: 4mm 5mm 3.5mm;
    border-right: 1px solid var(--border);
  }

  .cover-meta > div:nth-child(3n) { border-right: 0; }

  .cover-meta dt {
    margin: 0 0 1.8mm;
    color: var(--accent);
    font-size: 7pt;
    font-weight: 800;
    letter-spacing: 0.14em;
    text-transform: uppercase;
  }

  .cover-meta dd {
    margin: 0;
    color: var(--ink);
    font-size: 10pt;
    font-weight: 700;
    line-height: 1.25;
  }

  h1 {
    margin: 0 0 5mm;
    padding-bottom: 2mm;
    border-bottom: 2px solid var(--accent);
    color: var(--accent);
    font-size: 20pt;
    font-weight: 800;
    line-height: 1.15;
    letter-spacing: -0.02em;
  }

  h2 {
    margin: 5mm 0 2mm;
    color: var(--accent);
    font-size: 14pt;
    font-weight: 800;
    page-break-after: avoid;
  }

  h3 {
    margin: 3.2mm 0 1.2mm;
    color: var(--ink);
    font-size: 11.6pt;
    font-weight: 800;
    page-break-after: avoid;
  }

  p { margin: 0 0 2.2mm; }
  ul { margin: 2mm 0 3mm; padding-left: 5mm; }
  li { margin: 0 0 1mm; }

  .toc { list-style: none; margin: 7mm 0; padding: 0; }
  .toc li {
    display: flex;
    justify-content: space-between;
    gap: 3mm;
    margin: 0;
    padding: 1.7mm 0;
    border-bottom: 1px dotted var(--border-strong);
  }
  .toc li.section-head {
    margin-top: 2.5mm;
    border-bottom: 1px solid var(--border-strong);
    font-weight: 800;
  }
  .toc .page-num {
    color: var(--accent);
    font-weight: 800;
    font-variant-numeric: tabular-nums;
  }

  table {
    width: 100%;
    margin: 2.5mm 0 5mm;
    border-collapse: collapse;
    font-size: 8.2pt;
    page-break-inside: auto;
  }
  thead { display: table-header-group; }
  tr { page-break-inside: avoid; }
  th, td {
    border-bottom: 1px solid var(--border);
    padding: 1.6mm 2mm;
    text-align: left;
    vertical-align: top;
  }
  th {
    border-bottom: 2px solid var(--accent);
    background: var(--accent-light);
    color: var(--accent);
    font-size: 7.2pt;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
  }

  code {
    border-radius: 2px;
    background: var(--code-bg);
    color: #24364d;
    padding: 0.35mm 1mm;
    font-family: "SF Mono", Menlo, Consolas, monospace;
    font-size: 0.88em;
  }

  .callout {
    margin: 3mm 0;
    border-left: 3px solid var(--accent);
    border-radius: 2px;
    background: var(--accent-light);
    padding: 2.5mm 4mm;
    color: #24364d;
    font-size: 9.2pt;
  }

  .erd {
    margin: 2.5mm 0 3.5mm;
    padding: 2.2mm;
    border: 1px solid var(--border);
    border-radius: 3px;
    background: #fbfdff;
    break-inside: avoid;
    page-break-inside: avoid;
  }

  .erd-caption {
    margin-top: 1.2mm;
    color: var(--muted);
    font-size: 8pt;
    font-style: italic;
  }

  @page { size: A4; }
</style>
</head>
<body>
${body}
</body>
</html>`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

const args = parseArgs(process.argv.slice(2));
const inputPath = isAbsolute(args.input) ? args.input : resolve(process.cwd(), args.input);
const outPath = isAbsolute(args.out) ? args.out : resolve(process.cwd(), args.out);

const source = readFileSync(inputPath, "utf8");
const body = hasFullHtml(source) ? extractBody(source) : source;
const extraHead = hasFullHtml(source) ? (source.match(/<head[^>]*>([\s\S]*?)<\/head>/i)?.[1] ?? "") : "";
const html = buildHtml({ title: args.title, body, extraHead });

const tempDir = mkdtempSync(resolve(tmpdir(), "kernel-pdf-"));
const bundledPath = resolve(tempDir, "document.html");
writeFileSync(bundledPath, html, "utf8");

const logoDataUrl = fileToDataUrl(resolve(assetsDir, "kernel-logo.svg"), "image/svg+xml");

const chromeStyle = `
  <style>
    :root {
      --blue: #1459b8;
      --blue-light: #6c9bd2;
      --line: #d3e0f1;
      --ink: #293343;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; }
    svg { display: block; width: 100%; height: 100%; }
    img { display: block; }
    text { font-family: Arial, Helvetica, sans-serif; }
  </style>
`;

const headerTemplate = `
  ${chromeStyle}
  <div style="position:relative;width:100%;height:31mm;overflow:hidden;background:#fff;transform:translateY(-5mm);">
    <div style="position:absolute;top:0.8mm;left:0.8mm;width:14mm;height:14mm;border-top:1.5px solid var(--blue);border-left:1.5px solid var(--blue);"></div>
    <img src="${logoDataUrl}" alt="Kernel International Ltd." style="position:absolute;top:1.5mm;left:18mm;width:41.4mm;height:28mm;" />
    <svg viewBox="0 0 794 28" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="position:absolute;right:0;bottom:0;width:100%;height:7mm;">
      <path d="M0 26.5h794" stroke="#9dbbe0" stroke-width="1"/>
      <path d="M538 26.5 562 4h232v22.5Z" fill="#1459b8"/>
      <path d="M520 26.5 544 4h10l-24 22.5Z" fill="#6c9bd2"/>
      <path d="M532 26.5 556 4" stroke="#fff" stroke-width="3"/>
    </svg>
  </div>
`;

const footerTemplate = `
  ${chromeStyle}
  <div style="position:relative;width:100%;height:19mm;overflow:hidden;border-top:1.5px solid var(--blue);background:#fff;color:var(--ink);font-family:Arial,Helvetica,sans-serif;transform:translateY(5mm);">
    <div style="position:absolute;right:0.8mm;bottom:0.8mm;width:14mm;height:14mm;border-right:1.5px solid var(--blue);border-bottom:1.5px solid var(--blue);"></div>
    <div style="position:relative;z-index:2;display:flex;align-items:center;height:100%;padding:1mm 18mm 3.5mm;font-size:8.2pt;">
      <div style="display:grid;grid-template-columns:7mm auto;align-items:center;gap:2.5mm;white-space:nowrap;">
        <svg viewBox="0 0 24 24" aria-hidden="true" style="width:5.3mm;height:5.3mm;fill:none;stroke:var(--blue);stroke-linecap:round;stroke-linejoin:round;stroke-width:1.8;">
          <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>
        </svg>
        <span style="display:grid;gap:.8mm;">
          <span style="color:var(--blue);font-size:6pt;font-weight:800;letter-spacing:.12em;text-transform:uppercase;">Office</span>
          <span style="color:var(--ink);font-weight:600;">Progress Kohinoor, House 18, Road 10, Gulshan 1</span>
        </span>
      </div>
      <div style="display:grid;grid-template-columns:7mm auto;align-items:center;gap:2.5mm;margin-left:auto;padding-left:10mm;border-left:1px solid var(--line);white-space:nowrap;">
        <svg viewBox="0 0 24 24" aria-hidden="true" style="width:5.3mm;height:5.3mm;fill:none;stroke:var(--blue);stroke-linecap:round;stroke-linejoin:round;stroke-width:1.8;">
          <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/>
        </svg>
        <span style="display:grid;gap:.8mm;">
          <span style="color:var(--blue);font-size:6pt;font-weight:800;letter-spacing:.12em;text-transform:uppercase;">Telephone</span>
          <span style="color:var(--ink);font-weight:600;">01348 061944</span>
        </span>
      </div>
    </div>
    <svg viewBox="0 0 794 14" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="position:absolute;bottom:0;left:0;width:100%;height:3.5mm;">
      <path d="M0 0h220l16 14H0Z" fill="#1459b8"/>
      <path d="M220 0h10l16 14h-10Z" fill="#fff"/>
      <path d="M230 0h9l16 14h-9Z" fill="#6c9bd2"/>
    </svg>
  </div>
`;

const browser = await chromium.launch({ channel: "chrome" });
const page = await browser.newPage();

page.on("console", (msg) => {
  if (msg.type() === "error") console.error("[page]", msg.text());
});
page.on("pageerror", (err) => console.error("[pageerror]", err.message));

await page.goto(`file://${bundledPath}`, { waitUntil: "networkidle" });

if (args.waitForRenderComplete) {
  await page.waitForFunction(() => window.__renderComplete === true, null, {
    timeout: 60000,
  });
}

await page.waitForTimeout(300);

await page.pdf({
  path: outPath,
  format: "A4",
  printBackground: true,
  margin: {
    top: args.topMargin,
    right: args.rightMargin,
    bottom: args.bottomMargin,
    left: args.leftMargin,
  },
  displayHeaderFooter: true,
  headerTemplate,
  footerTemplate,
  preferCSSPageSize: true,
});

await browser.close();
rmSync(tempDir, { recursive: true, force: true });
console.log(`Wrote ${outPath}`);
